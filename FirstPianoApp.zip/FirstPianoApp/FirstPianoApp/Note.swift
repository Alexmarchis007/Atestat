//
//  Note.swift
//  FirstPianoApp
//
//  Created by Alex on 15/05/2017.
//  Copyright © 2017 Alex. All rights reserved.
//

import UIKit


///var ButtonArray : Array = [C3]

class Note: NSObject{

    @IBAction func ButtonPush(_ sender : Any){
        
    }
    
}
